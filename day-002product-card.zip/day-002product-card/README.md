# Day 002 - Product Card

A Pen created on CodePen.

Original URL: [https://codepen.io/jonathanobino/pen/VedwMz](https://codepen.io/jonathanobino/pen/VedwMz).

http://www.100daysui.com/#cbp=ajax/shot-2